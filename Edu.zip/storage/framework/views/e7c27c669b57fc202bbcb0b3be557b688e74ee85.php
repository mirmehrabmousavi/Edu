<?php $__env->startSection('content'); ?>
    <div class="row" id="table-striped">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">تیکت ها</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <?php if($tickets->isEmpty()): ?>
                            <p>تیکت وجود ندارد</p>
                        <?php else: ?>
                            <table class="table table-striped mb-0">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">دسته بندی</th>
                                    <th scope="col">عنوان</th>
                                    <th scope="col">وضعیت</th>
                                    <th scope="col">آخرین ویرایش</th>
                                    <th scope="col"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                                        <td><?php echo e($ticket->category_id); ?></td>
                                        <td><a href="<?php echo e(url('tickets/'. $ticket->ticket_id)); ?>">
                                                #<?php echo e($ticket->ticket_id); ?> - <?php echo e($ticket->title); ?>

                                            </a></td>
                                        <td><?php if($ticket->status === 'باز است'): ?>
                                                <div class="badge pill-badge badge-success"><?php echo e($ticket->status); ?></div>
                                            <?php else: ?>
                                                <div class="badge pill-badge badge-danger"><?php echo e($ticket->status); ?></div>
                                            <?php endif; ?></td>
                                        <td><?php echo e($ticket->updated_at->toJalali()->formatDifference()); ?></td>
                                        <td>
                                            <?php if($ticket->status === 'باز است'): ?>
                                                <a href="<?php echo e(url('tickets/' . $ticket->ticket_id)); ?>"
                                                   class="btn bg-gradient-primary mr-1 mb-1 waves-effect waves-light">پاسخ</a>
                                                <form action="<?php echo e(url('admin/close_ticket/' . $ticket->ticket_id)); ?>"
                                                      method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn bg-gradient-danger mr-1 mb-1 waves-effect waves-light">بستن</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/tickets.blade.php ENDPATH**/ ?>