<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">پرداخت ها</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">عنوان پرداخت</th>
                                <th scope="col">جمع کل</th>
                                <th scope="col">تاریخ</th>
                                <th scope="col">وضعیت</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">#0000<?php echo e(+$loop->index+1); ?></th>
                                    <?php $course = \App\Models\Course::where('id',$val->course_id)->first() ?>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($val->paid); ?></td>
                                    <td><?php echo e($val->created_at->diffForHumans()); ?></td>
                                    <?php
                                        $status = 'موفق';
                                        $color = '';
                                        switch ($val->status) {
                                            case 0:
                                                $status = 'کنسل شده';
                                                $color = 'danger';
                                                break;
                                            case 1:
                                                $status = 'در انتظار پرداخت';
                                                $color = 'warning';
                                                break;
                                            case 2:
                                                $status = 'موفق';
                                                $color = 'success';
                                                break;
                                        }
                                    ?>
                                    <td><span class="badge badge-<?php echo e($color); ?>"><?php echo e($status); ?></span></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/pays.blade.php ENDPATH**/ ?>