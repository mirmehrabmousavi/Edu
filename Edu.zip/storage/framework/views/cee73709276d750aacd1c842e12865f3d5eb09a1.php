<?php $__env->startSection('content'); ?>
    <!-- ============================ Page Title Start================================== -->
    <section class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">

                    <div class="breadcrumbs-wrap">
                        <h1 class="breadcrumb-title">افزودن به سبد خرید</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">خانه</a></li>
                                <li class="breadcrumb-item active" aria-current="page">افزودن به سبد خرید</li>
                            </ol>
                        </nav>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- ============================ Page Title End ================================== -->


    <!-- ============================ Add To cart ================================== -->
    <section class="pt-0">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">

                    <div class="table-responsive">
                        <table class="table add_to_cart">
                            <thead>
                            </thead>
                            <tbody>
                            <tr>
                                <td><div class="tb_course_thumb"><img src="<?php echo e(($course->c_poster != null) ? $course->c_poster : url('/upload/no-image.png')); ?>" class="img-fluid" alt="" /></div></td>
                                <th><?php echo e($course->title); ?></th>
                                <td><span class="wish_price theme-cl"><?php echo e($course->price); ?> تومان</span></td>
                                <td><span class="wish_price theme-cl"><?php echo e($course->d_price); ?> دلار</span></td>
                                <td><p><?php echo e($course->b_desc); ?></p></td>
                                <td><p><?php echo e($course->time); ?></p></td>
                                <td><p><?php echo e($course->status); ?></p></td>
                                <td><p><?php echo e($course->language); ?></p></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>

            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <!-- Total Cart -->
                    <div class="cart_totals checkout">
                        <h4>صورت حساب زرین پال</h4>
                        <div class="cart-wrap">
                            <ul class="cart_list">
                                <li>قیمت<strong><?php echo e($course->price); ?> تومان</strong></li>
                                <li>با تخفیف<strong><?php echo e($course->price_off); ?> تومان</strong></li>
                            </ul>
                            <div class="flex_cart">
                                <div class="flex_cart_1">
                                    جمع کل
                                </div>
                                <div class="flex_cart_2">
                                    <?php echo e($course->price_off); ?> تومان
                                </div>
                            </div>
                            <a href="<?php echo e(route('purchase',['id' => $course->id])); ?>" class="btn checkout_btn">پرداخت</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <!-- Total Cart -->
                    <div class="cart_totals checkout">
                        <h4> PayPal صورت حساب</h4>
                        <div class="cart-wrap">
                            <ul class="cart_list">
                                <li>قیمت<strong><?php echo e($course->d_price); ?> دلار</strong></li>
                                <li>با تخفیف<strong><?php echo e($course->d_price_off); ?> دلار</strong></li>
                            </ul>
                            <div class="flex_cart">
                                <div class="flex_cart_1">
                                    جمع کل
                                </div>
                                <div class="flex_cart_2">
                                    <?php echo e($course->d_price_off); ?> دلار
                                </div>
                            </div>
                            <a href="<?php echo e(route('purchase',['id' => $course->id ,'d_price' => $course->d_price_off])); ?>" class="btn checkout_btn">پرداخت</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- ============================ Add To cart End ================================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/course/bill.blade.php ENDPATH**/ ?>