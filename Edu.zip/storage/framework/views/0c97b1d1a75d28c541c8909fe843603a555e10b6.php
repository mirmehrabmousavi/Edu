<?php $__env->startSection('content'); ?>
    <section id="page-account-settings">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-header">
                            <p class="card-title">
                                ویرایش نظر
                            </p>
                        </div>
                        <div class="card-body">
                            <form novalidate="" action="<?php echo e(route('admin.updateComment',['id' => $comment->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-username">پروفایل</label>
                                                        <input type="text" class="form-control" name="profile"
                                                               id="account-username" placeholder="پروفایل"
                                                               value="<?php echo e($comment->profile); ?>"
                                                               required="" data-validation-required-message="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-username">نام</label>
                                                        <input type="text" class="form-control" name="name"
                                                               id="account-username" placeholder="نام"
                                                               value="<?php echo e($comment->name); ?>"
                                                               required="" data-validation-required-message="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-username">گروه</label>
                                                        <input type="text" class="form-control" name="group"
                                                               id="account-username" placeholder="گروه"
                                                               value="<?php echo e($comment->group); ?>"
                                                               required="" data-validation-required-message="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-username">پیام</label>
                                                        <textarea name="message" id="message" cols="30"
                                                                  rows="10" class="form-control" placeholder="پیام"><?php echo e($comment->message); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                        <button type="submit"
                                                class="btn btn-primary mr-sm-1 mb-1 mb-sm-0 waves-effect waves-light">
                                            بروزرسانی
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/comment/edit.blade.php ENDPATH**/ ?>