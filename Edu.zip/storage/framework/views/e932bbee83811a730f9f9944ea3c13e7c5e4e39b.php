<?php $__env->startSection('content'); ?>
    admin temp
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\MyShop\resources\views/admin/home.blade.php ENDPATH**/ ?>