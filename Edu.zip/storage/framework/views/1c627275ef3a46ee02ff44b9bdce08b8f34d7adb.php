<?php $__env->startSection('content'); ?>
    <!-- ============================ Course Detail ================================== -->
    <section class="pt-5">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb simple">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>" class="theme-cl">خانه</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('courses')); ?>" class="theme-cl">لیست دوره</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($course->title); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>

            <div class="row">

                <div class="col-lg-8 col-md-8">

                    <div class="inline_edu_wraps mb-4">
                        <h2><?php echo e($course->title); ?></h2>
                        <div class="ed_rate_info">
                            <span
                                class="ml-2 text-danger bg-light-danger px-2 py-1 rounded"><?php echo e($course->category_id); ?></span>
                            <div class="review_counter mr-2">
                                <strong class="good">4.5</strong>
                            </div>
                            <div class="star_info">
                                <i class="fas fa-star filled"></i>
                                <i class="fas fa-star filled"></i>
                                <i class="fas fa-star filled"></i>
                                <i class="fas fa-star filled"></i>
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                    </div>

                    <div class="inline_edu_wrap">
                        <div class="inline_edu_first">
                            <div class="instructor_dark_info">
                                <ul>
                                    <li>
                                        <span>آخرین آپدیت</span>
                                        <?php echo e($course->updated_at->diffForHumans()); ?>

                                    </li>
                                    <li>
                                        <span>شرکت کننده</span>
                                        742,614
                                    </li>
                                    <li>
                                        <span>زبان</span>
                                        <?php echo e($course->language); ?>

                                    </li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>

                    <div class="property_video xl mb-4">
                        <div class="thumb">
                            <img class="pro_img img-fluid w100"
                                 src="<?php echo e(($course->c_poster != null) ? $course->c_poster : url('/upload/no-image.png')); ?>"
                                 alt="7.jpg">
                            <div class="overlay_icon">
                                <div class="bb-video-box">
                                    <div class="bb-video-box-inner">
                                        <div class="bb-video-box-innerup">
                                            <a href="<?php echo e(($course->c_demo != null) ? $course->c_demo : ($course->c_poster != null) ? $course->c_poster : url('/upload/no-image.png')); ?>"
                                               data-toggle="modal" data-target="#popup-video" class="theme-cl"><i
                                                    class="ti-control-play"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Overview -->
                    <div class="edu_wraper border">
                        <h4 class="edu_title">توضیحات</h4>
                        <?php echo $course->desc; ?>


                    </div>

                    <div class="edu_wraper border">
                        <h4 class="edu_title">سرفصل های دوره</h4>
                        <div id="accordionExample" class="accordion shadow circullum">
                        <?php $lesson = \App\Models\Lesson::where('user_id',$course->user_id)->where('l_course',$course->title)->get(); ?>
                        <?php $season = \App\Models\Season::where('user_id',$course->user_id)->where('course',$course->title)->get(); ?>
                        <?php $__currentLoopData = $lesson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $season; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Part 1 -->
                                <div class="card">
                                    <div id="headingOne" class="card-header bg-white shadow-sm border-0">
                                        <h6 class="mb-0 accordion_title"><a href="#" data-toggle="collapse"
                                                                            data-target="#collapseOne"
                                                                            aria-expanded="true"
                                                                            aria-controls="collapseOne"
                                                                            class="d-block position-relative text-dark collapsible-link py-2"><?php echo e($sea->title); ?></a></h6>
                                    </div>
                                    <div id="collapseOne" aria-labelledby="headingOne" data-parent="#accordionExample"
                                         class="collapse show">
                                        <div class="card-body pl-3 pr-3">
                                            <ul class="lectures_lists">
                                                <li <?php echo e(($val->l_free == 'on') ? '' : 'class="unview'); ?>>
                                                    <div class="lectures_lists_title"><i class="ti-control-play"></i>دوره:
                                                        <?php echo e($loop->index+1); ?>

                                                    </div>
                                                    <?php echo e($val->title); ?>

                                                    <a href="<?php echo e($val->l_file); ?>" class="btn btn-sm btn-light rounded mr-4"><i class="fa fa-download"></i></a>
                                                    <a href="<?php echo e($val->l_video); ?>" class="btn btn-sm btn-light rounded mr-4"><i class="fa fa-video"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                <?php $user = \App\Models\User::where('email',$course->user_id)->get(); ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- instructor -->
                        <div class="single_instructor border">
                            <div class="single_instructor_thumb">
                                <a href="#"><img
                                        src="<?php echo e(($us->profile == null) ? '/upload/no-profile.jpg' : $us->profile); ?>"
                                        class="img-fluid" alt=""></a>
                            </div>
                            <div class="single_instructor_caption">
                                <h4><a href="#"><?php echo e(($us->fname == null) ? $us->email : $us->fname.' '.$us->lname); ?></a>
                                </h4>
                                <ul class="instructor_info">
                                    <?php $lessons = \App\Models\Lesson::where('user_id',$us->email)->get(); ?>
                                    <li><i class="ti-video-camera"></i><?php echo e(count($lessons)); ?> ویدئو</li>
                                    <?php $courses = \App\Models\Course::where('user_id',$us->email)->get(); ?>
                                    <li><i class="ti-control-forward"></i><?php echo e(count($courses)); ?> دوره</li>
                                    <li><i class="ti-user"></i><?php echo e($us->updated_at->diffForHumans()); ?></li>
                                </ul>
                                <p><?php echo e($us->bio); ?></p>
                                <ul class="social_info">
                                    <li><a href="<?php echo e($us->facebook); ?>"><i class="ti-facebook"></i></a></li>
                                    <li><a href="<?php echo e($us->twitter); ?>"><i class="ti-twitter"></i></a></li>
                                    <li><a href="<?php echo e($us->linkedin); ?>"><i class="ti-linkedin"></i></a></li>
                                    <li><a href="<?php echo e($us->instagram); ?>"><i class="ti-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>

                <div class="col-lg-4 col-md-4">

                    <!-- Course info -->
                    <div class="ed_view_box style_3 border py-3">

                        <div class="ed_view_price pr-4">
                            <h5>قیمت آموزش</h5>
                            <h2 class="theme-cl mb-0"><?php echo e($course->price); ?></h2>
                            <div class="offer-box"><span class="offer-box"><?php echo e($course->price_off); ?></span></div>
                        </div>

                        <div class="ed_view_price pr-4">
                            <h5>قیمت آموزش(دلار)</h5>
                            <h2 class="theme-cl mb-0"><?php echo e($course->d_price); ?></h2>
                            <div class="offer-box"><span class="offer-box"><?php echo e($course->d_price_off); ?></span></div>
                        </div>

                        <div class="ed_view_short pl-4 pr-4 pb-2 b-b">
                            <h6>خلاصه توضیحات :</h6>
                            <p><?php echo e($course->b_desc); ?></p>
                        </div>

                        <div class="p-4">
                            <h5 class="edu_title">ویژگی های دوره</h5>
                            <ul class="edu_list right">
                                <li><i class="ti-user"></i>شرکت کنندگان:<strong>1740 نفر</strong></li>
                                <?php $lesson = \App\Models\Lesson::where('user_id',$course->user_id)->get(); ?>
                                <li><i class="ti-game"></i>جلسات:<strong><?php echo e(count($lesson)); ?></strong></li>
                                <li><i class="ti-time"></i>مدت دوره:<strong><?php echo e($course->time); ?></strong></li>
                                <li><i class="ti-tag"></i>وضعیت دوره:<strong><?php echo e($course->status); ?></strong></li>
                                <li><i class="ti-flag-alt"></i>زبان:<strong><?php echo e($course->language); ?></strong></li>
                                <li><i class="ti-shine"></i>نوع
                                    دوره:<strong><?php echo e(($course->price == '0') ? 'رایگان' : 'غیر رایگان'); ?></strong></li>
                            </ul>
                        </div>
                        <div class="ed_view_link pb-3">
                            <a href="<?php echo e(route('addToSavedCourse',['id' => $course->id])); ?>" class="btn btn-outline-theme enroll-btn" onclick="event.preventDefault();
                                                     document.getElementById('add').submit();">افزودن به مورد علاقه<i
                                    class="fa fa-heart"></i></a>
                            <form action="<?php echo e(route('addToSavedCourse',['id' => $course->id])); ?>" id="add" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                            </form>
                            <?php $purchased = \App\Models\PurchasedCourse::where('user_id',auth()->user()->email)->where('course_id',$course->id)->exists() ?>
                            <?php if($purchased): ?>
                                <p class="btn btn-theme enroll-btn">دانشجوی دوره هستید</p>
                            <?php else: ?>
                                <a href="<?php echo e(route('goBilling',['id' => $course->id])); ?>" class="btn btn-theme enroll-btn">خرید دوره<i class="ti-angle-left"></i></a>
                            <?php endif; ?>
                        </div>


                        <?php $user = \App\Models\User::where('email',$course->user_id)->get(); ?>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="px-4 pt-4 pb-0 b-t">
                                <h5 class="mb-3">درباره مدرس</h5>
                                <div class="ins_info">
                                    <div class="ins_info_thumb">
                                        <img src="<?php echo e(($us->profile == null) ? '/upload/no-profile.jpg' : $us->profile); ?>"
                                             class="img-fluid" alt="">
                                    </div>
                                    <div class="ins_info_caption">
                                        <h4 class="text-dark"><?php echo e(($us->fname == null) ? $us->email : $us->fname.' '.$us->lname); ?></h4>
                                        <span class="text-dark"><?php echo e($us->job); ?></span>
                                    </div>
                                </div>
                                <div class="inline_edu_wrap mt-4">
                                    <div class="inline_edu_first">
                                        <div class="ed_rate_info">
                                            <div class="review_counter mr-2">
                                                <strong class="good">4.5</strong>
                                            </div>
                                            <div class="star_info">
                                                <i class="fas fa-star filled"></i>
                                                <i class="fas fa-star filled"></i>
                                                <i class="fas fa-star filled"></i>
                                                <i class="fas fa-star filled"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inline_edu_last">
                                        <?php $courses = \App\Models\Course::where('user_id',$us->email)->get(); ?>
                                        <i class="fa fa-file ml-2"></i><?php echo e(count($courses)); ?> دوره
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

            </div>

        </div>
    </section>
    <!-- ============================ Course Detail ================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/course/show.blade.php ENDPATH**/ ?>