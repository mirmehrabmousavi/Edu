<?php $__env->startSection('content'); ?>
    <div class="col-lg-9 col-md-9 col-sm-12">

        <!-- Row -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 pb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">خانه</a></li>
                        <li class="breadcrumb-item active" aria-current="page">افزودن درس جدید</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- /Row -->

        <form action="<?php echo e(route('storeLesson')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- Row -->
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard_container">
                        <div class="dashboard_container_header">
                            <div class="dashboard_fl_1">
                                <h4>افزودن درس جدید</h4>
                            </div>
                        </div>
                        <div class="dashboard_container_body p-4">
                            <!-- Basic info -->
                            <div class="submit-section">
                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>عنوان</label>
                                        <input type="text" class="form-control" name="title" placeholder="عنوان" required>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>فایل درس</label>
                                        <input type="file" name="l_file" class="form-control" placeholder="فایل درس" required>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>ویدیو درس</label>
                                        <input type="file" name="l_video" class="form-control" placeholder="ویدیو درس" required>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>انتخاب دوره</label>
                                        <select name="l_course" id="l_course" class="form-control">
                                            <?php $course = \App\Models\Course::all(); ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($courses->title); ?>"><?php echo e($courses->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>فصل</label>
                                        <select name="season" id="season" class="form-control">
                                            <option value="فصل اول">فصل اول</option>
                                            <option value="فصل دوم">فصل دوم</option>
                                            <option value="فصل سوم">فصل سوم</option>
                                            <option value="فصل چهارم">فصل چهارم</option>
                                            <option value="فصل پنجم">فصل پنجم</option>
                                            <option value="فصل ششم">فصل ششم</option>
                                            <option value="فصل هفتم">فصل هفتم</option>
                                            <option value="فصل هشتم">فصل هشتم</option>
                                            <option value="فصل نهم">فصل نهم</option>
                                            <option value="فصل دهم">فصل دهم</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <input id="a-1" class="checkbox-custom" name="l_free" type="checkbox">
                                        <label for="a-1" class="checkbox-custom-label">رایگان</label>
                                    </div>

                                </div>
                            </div>
                            <!-- Basic info -->

                        </div>

                    </div>
                </div>
                <div class="form-group col-lg-12 col-md-12">
                    <button class="btn btn-theme" type="submit">ذخیره</button>
                </div>
            </div>
            <!-- /Row -->

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/dashboard/add-lesson.blade.php ENDPATH**/ ?>