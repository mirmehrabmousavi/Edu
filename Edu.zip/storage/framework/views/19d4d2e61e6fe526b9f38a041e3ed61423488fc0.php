<?php $__env->startSection('content'); ?>
    <div class="ed_detail_head">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-5">

                    <div class="property_video">
                        <div class="thumb">
                            <img class="pro_img img-fluid w100" src="<?php echo e((empty($class->poster) ? '/upload/no-image.png' : $class->poster)); ?>" alt="<?php echo e($class->topic); ?>">
                        </div>
                    </div>

                </div>

                <div class="col-lg-8 col-md-7">
                    <div class="ed_detail_wrap">
                        <ul class="cources_facts_list">
                            <li class="facts-1">کلاس</li>
                        </ul>
                        <div class="ed_header_caption">
                            <h2 class="ed_title"><?php echo e($class->topic); ?></h2>
                            <ul>
                                <li><i class="ti-calendar"></i>تاریخ شروع : <?php echo e($class->start_time); ?></li>
                                <li><i class="ti-control-forward"></i>مدت زمان : <?php echo e($class->duration); ?></li>
                            </ul>
                        </div>
                        <div class="ed_header_short">
                            <p>قیمت : <?php if(empty($class->price)): ?> رایگان <?php else: ?> <?php echo e($class->price); ?> تومان <?php endif; ?></p>
                            <p>قیمت (دلار) : <?php if(empty($class->d_price)): ?> رایگان <?php else: ?> <?php echo e($class->d_price); ?> تومان <?php endif; ?></p>
                            <p><a class="btn btn-primary mr-sm-1 mb-1 mb-sm-0 waves-effect waves-light" href="<?php echo e($class->join_url); ?>">ورود به کلاس</a></p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/class/show.blade.php ENDPATH**/ ?>