<?php $__env->startSection('content'); ?>
    <section class="page-users-view">
        <div class="row">
            <!-- information start -->
            <div class="col-md-6 col-12 ">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title mb-2">اطلاعات</div>
                    </div>
                    <div class="card-body">
                        <table>
                            <tbody>
                            <tr class="p-1">
                                <td class="font-weight-bold">نام :</td>
                                <td><?php echo e($coll->name); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">نام خانوادگی :</td>
                                <td><?php echo e($coll->family); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">ایمیل :</td>
                                <td><?php echo e($coll->email); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">شماره تماس :</td>
                                <td><?php echo e($coll->number); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">آدرس :</td>
                                <td><?php echo e($coll->address); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">عنوان :</td>
                                <td><?php echo e($coll->title); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">توضیحات :</td>
                                <td><?php echo e($coll->desc); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- information start -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/collaborate/show.blade.php ENDPATH**/ ?>