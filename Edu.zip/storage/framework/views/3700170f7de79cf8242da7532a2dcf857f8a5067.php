<?php $__env->startSection('content'); ?>
    <div class="col-lg-9 col-md-9 col-sm-12">

        <!-- Row -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 pb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">خانه</a></li>
                        <li class="breadcrumb-item active" aria-current="page">افزودن دوره جدید</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- /Row -->

        <form action="<?php echo e(route('updateCourse',['id' => $course->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
        <!-- Row -->
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard_container">
                        <div class="dashboard_container_header">
                            <div class="dashboard_fl_1">
                                <h4>ویرایش دوره</h4>
                            </div>
                        </div>
                        <div class="dashboard_container_body p-4">
                            <!-- Basic info -->
                            <div class="submit-section">
                                <div class="form-row">

                                    <div class="form-group col-md-12">
                                        <label>عنوان</label>
                                        <input type="text" value="<?php echo e($course->title); ?>" class="form-control" name="title" placeholder="عنوان" required>
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label>توضیحات</label>
                                        <textarea class="form-control" name="desc" placeholder="توضیحات" required><?php echo e($course->desc); ?></textarea>
                                    </div>

                                    <div class="form-group col-md-12">
                                        <label>خلاصه توضیحات</label>
                                        <input type="text" value="<?php echo e($course->b_desc); ?>" class="form-control" name="b_desc" placeholder="خلاصه توضیحات" required>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>قیمت</label>
                                        <input type="text" value="<?php echo e($course->price); ?>" name="price" class="form-control" placeholder="قیمت">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>قیمت تخفیف خورده</label>
                                        <input type="text" value="<?php echo e($course->price_off); ?>" name="price_off" class="form-control" placeholder="قیمت تخفیف خورده">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>قیمت (دلار)</label>
                                        <input type="text" value="<?php echo e($course->d_price); ?>" name="d_price" class="form-control" placeholder="قیمت (دلار)">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>قیمت تخفیف خورده (دلار)</label>
                                        <input type="text" value="<?php echo e($course->d_price_off); ?>" name="d_price_off" class="form-control" placeholder="قیمت تخفیف خورده (دلار)">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>پوستر دوره</label>
                                        <input type="file" name="c_poster" class="form-control" placeholder="پوستر دوره">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>دمو دوره</label>
                                        <input type="file" name="c_demo" class="form-control" placeholder="دمو دوره">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>مدت زمان دوره</label>
                                        <input type="text" value="<?php echo e($course->time); ?>" name="time" class="form-control" placeholder="مدت زمان دوره">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>وضعیت دوره</label>
                                        <select name="status" id="category" class="form-control">
                                            <option value="در حال برگذاری"  <?php echo e($course->status == 'در حال برگذاری' ? 'selected' : ''); ?>>در حال برگذاری</option>
                                            <option value="تکمیل شده"  <?php echo e($course->status == 'تکمیل شده' ? 'selected' : ''); ?>>تکمیل شده</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>زبان دوره</label>
                                        <select class="form-control" name="language">
                                            <option value="english" <?php echo e($course->language == 'english' ? 'selected' : ''); ?>>انگلیسی</option>
                                            <option value="spanish" <?php echo e($course->language == 'spanish' ? 'selected' : ''); ?>>اسپانیایی</option>
                                            <option value="french" <?php echo e($course->language == 'french' ? 'selected' : ''); ?>>فرانسوی</option>
                                            <option value="russian" <?php echo e($course->language == 'russian' ? 'selected' : ''); ?>>روسی</option>
                                            <option value="turkish" <?php echo e($course->language == 'turkish' ? 'selected' : ''); ?>>ترکی</option>
                                            <option value="chinese" <?php echo e($course->language == 'chinese' ? 'selected' : ''); ?>>چینی</option>
                                            <option value="italy" <?php echo e($course->language == 'italy' ? 'selected' : ''); ?>>ایتالیایی</option>
                                            <option value="germany" <?php echo e($course->language == 'germany' ? 'selected' : ''); ?>>آلمانی</option>
                                            <option value="arabic" <?php echo e($course->language == 'arabic' ? 'selected' : ''); ?>>عربی</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label>دسته بندی دوره</label>
                                        <select name="category_id" id="category" class="form-control">
                                            <?php if(!empty($cat)): ?>
                                                <option value="">بدون دسته بندی</option>
                                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $dash=''; ?>
                                                    <option value="<?php echo e($val->category_name); ?>" <?php echo e($val->category_name == $val->category_name ? 'selected' : ''); ?>><?php echo e($val->category_name); ?></option>
                                                    <?php if(count($val->subcategory)): ?>
                                                        <?php echo $__env->make('admin.categories.subCategoryList',['subcategories' => $val->subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="">بدون دسته بندی</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Basic info -->

                        </div>

                    </div>
                </div>
                <div class="form-group col-lg-12 col-md-12">
                    <button class="btn btn-theme" type="submit">بروزرسانی</button>
                </div>
            </div>
            <!-- /Row -->

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/dashboard/edit-course.blade.php ENDPATH**/ ?>