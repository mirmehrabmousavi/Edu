<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">درخواست ها</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">نام</th>
                                <th scope="col">خانوادگی</th>
                                <th scope="col">ایمیل</th>
                                <th scope="col">شماره تماس</th>
                                <th scope="col">آدرس</th>
                                <th scope="col">عنوان</th>
                                <th scope="col">توضیحات</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $collaborate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->family); ?></td>
                                    <td><?php echo e($value->email); ?></td>
                                    <td><?php echo e($value->number); ?></td>
                                    <td><?php echo e($value->address); ?></td>
                                    <td><?php echo e($value->title); ?></td>
                                    <td><?php echo e($value->desc); ?></td>
                                    <td>
                                        <a class="btn btn-outline-danger round mr-1 mb-1 waves-effect waves-light" href="<?php echo e(route('admin.deleteCollaborate',['id' => $value->id])); ?>" onclick="event.preventDefault();
                                                     document.getElementById('del').submit();">حذف</a>
                                        <form id="del" action="<?php echo e(route('admin.deleteCollaborate',['id' => $value->id])); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/create.blade.php ENDPATH**/ ?>
