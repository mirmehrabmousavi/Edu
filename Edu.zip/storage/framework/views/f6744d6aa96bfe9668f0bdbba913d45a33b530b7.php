<?php $dash.='-- '; ?>
<?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($category->category_name != $subcategory->category_name ): ?>
        <option value="<?php echo e($subcategory->category_name); ?>" <?php if($category->parent_id == $subcategory->category_name ): ?> selected <?php endif; ?> >
            <?php echo e($dash); ?><?php echo e($subcategory->category_name); ?>

        </option>
    <?php endif; ?>
    <?php if(count($subcategory->subcategory)): ?>
        <?php echo $__env->make('admin.categories.subCategoryListUpdate',['subcategories' => $subcategory->subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Installed\www\Edu\resources\views/admin/categories/subCategoryListUpdate.blade.php ENDPATH**/ ?>