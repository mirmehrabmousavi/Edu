

<?php $__env->startSection('content'); ?>
  <div class="container">
      <section id="basic-horizontal-layouts">
          <div class="row">
              <div class="col-md-12 col-12">
                  <div class="card">
                      <div class="card-header">
                          <h4 class="card-title">ارسال تیکت جدید</h4>
                      </div>
                      <div class="card-content">
                          <div class="card-body">
                              <?php if(session('status')): ?>
                                  <div class="alert alert-success">
                                      <?php echo e(session('status')); ?>

                                  </div>
                              <?php endif; ?>
                              <form action="<?php echo e(route('ticket.store')); ?>" class="form form-horizontal" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <div class="form-body">
                                      <div class="row">
                                          <div class="col-12">
                                              <fieldset class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                                                  <label for="basicInput">عنوان</label>
                                                  <input type="text" class="form-control" name="title"
                                                         value="<?php echo e(old('title')); ?>" id="basicInput"
                                                         placeholder="عنوان را وارد کنید">
                                                  <?php if($errors->has('title')): ?>
                                                      <span class="help-block">
                                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                  <?php endif; ?>
                                              </fieldset>
                                          </div>
                                          <div class="col-12">
                                              <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                                                  <label for="type">
                                                      دسته بندی
                                                  </label>
                                                  <select class="custom-select form-control" id="type" name="category"
                                                          required>
                                                      <option value="">دسته بندی را انتخاب کنید</option>
                                                      <option value="ضعیف">ضعیف</option>
                                                      <option value="متوسط">متوسط</option>
                                                      <option value="قوی">قوی</option>
                                                      
                                                  </select>
                                                  <?php if($errors->has('category')): ?>
                                                      <span class="help-block">
                                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                                    </span>
                                                  <?php endif; ?>
                                              </div>
                                          </div>
                                          <div class="col-12">
                                              <div class="form-group<?php echo e($errors->has('priority') ? ' has-error' : ''); ?>">
                                                  <label for="type">
                                                      اولویت
                                                  </label>
                                                  <select class="custom-select form-control" id="type" name="priority"
                                                          required>
                                                      <option value="">اولویت را انتخاب کنید</option>
                                                      <option value="ضعیف">ضعیف</option>
                                                      <option value="متوسط">متوسط</option>
                                                      <option value="قوی">قوی</option>
                                                  </select>
                                                  <?php if($errors->has('priority')): ?>
                                                      <span class="help-block">
                                                        <strong><?php echo e($errors->first('priority')); ?></strong>
                                                    </span>
                                                  <?php endif; ?>
                                              </div>
                                          </div>
                                          <div class="col-12">
                                              <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?> row">
                                                  <div class="col-md-4">
                                                      <span>متن پیام</span>
                                                  </div>
                                                  <textarea name="message"
                                                            class="form-control char-textarea" rows="10"
                                                            placeholder="پیام" required></textarea>
                                                  <?php if($errors->has('message')): ?>
                                                      <span class="help-block">
                                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                                    </span>
                                                  <?php endif; ?>
                                              </div>
                                          </div>
                                          <div class="col-md-8">
                                              <button type="submit"
                                                      class="btn btn-primary mr-1 mb-1 waves-effect waves-light">ثبت
                                              </button>
                                          </div>
                                      </div>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/tickets/create.blade.php ENDPATH**/ ?>