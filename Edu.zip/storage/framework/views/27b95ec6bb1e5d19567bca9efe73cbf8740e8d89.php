<!-- Pagination -->
<?php if($paginator->hasPages()): ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <ul class="pagination p-center">
                <?php if($paginator->onFirstPage()): ?>
                    <li></li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" aria-label="Previous">
                            <span class="ti-arrow-right"></span>
                            <span class="sr-only">قبل</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($element)): ?>
                        <li class="page-item"><a class="page-link" href="#"><?php echo e($element); ?></a></li>
                    <?php endif; ?>

                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($paginator->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" aria-label="Next">
                            <span class="ti-arrow-left"></span>
                            <span class="sr-only">بعد</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\Installed\www\Edu\resources\views/pagination/paginate.blade.php ENDPATH**/ ?>