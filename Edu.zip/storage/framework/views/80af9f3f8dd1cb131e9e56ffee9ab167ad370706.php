<?php $__env->startSection('content'); ?>
    <div class="col-lg-9 col-md-9 col-sm-12">

        <!-- Row -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 pb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">خانه</a></li>
                        <li class="breadcrumb-item active" aria-current="page">پرداخت ها</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- /Row -->

        <!-- Row -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="dashboard_container">
                    <div class="dashboard_container_header">
                        <div class="dashboard_fl_1">
                            <h4>پرداخت ها</h4>
                        </div>
                    </div>
                    <div class="dashboard_container_body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-dark">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">عنوان پرداخت</th>
                                    <th scope="col">جمع کل</th>
                                    <th scope="col">تاریخ</th>
                                    <th scope="col">وضعیت</th>
                                    <th scope="col">عملیات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">#0000<?php echo e(+$loop->index+1); ?></th>
                                    <?php $course = \App\Models\Course::where('id',$val->course_id)->first() ?>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($val->paid); ?></td>
                                    <td><?php echo e($val->created_at->diffForHumans()); ?></td>
                                    <?php
                                        $status = 'موفق';
                                        $color = '';
                                        switch ($val->status) {
                                            case 0:
                                                $status = 'کنسل شده';
                                                $color = 'cancel';
                                                break;
                                            case 1:
                                                $status = 'در انتظار پرداخت';
                                                $color = 'pending';
                                                break;
                                            case 2:
                                                $status = 'موفق';
                                                $color = 'complete';
                                                break;
                                        }
                                    ?>
                                    <td><span class="payment_status <?php echo e($color); ?>"><?php echo e($status); ?></span></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($transaction->links('pagination.paginate')); ?>

                    </div>

                </div>
            </div>
        </div>
        <!-- /Row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/dashboard/pays.blade.php ENDPATH**/ ?>