<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="alert alert-warning"><p><i class="fa fa-info-circle"></i>    برای افزودن دوره حداقل یک دسته بندی اضافه کنید</p></div>
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">دوره</h4>
                    <a href="<?php echo e(route('admin.createCourse')); ?>" class="btn btn-outline-primary round mr-1 mb-1 waves-effect waves-light"><i class="fa fa-plus"></i>افزودن</a>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">نام دوره</th>
                                <th scope="col">خلاصه توضیحات</th>
                                <th scope="col">قیمت</th>
                                <th scope="col">قیمت به دلار</th>
                                <th scope="col">زمان دوره</th>
                                <th scope="col">وضعیت دوره</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($course->b_desc); ?></td>
                                    <td><?php echo e($course->price); ?></td>
                                    <td><?php echo e($course->d_price); ?></td>
                                    <td><?php echo e($course->time); ?></td>
                                    <td><?php echo e($course->status); ?></td>
                                    <td>
                                        <a href="<?php echo e(Route('admin.editCourse', ['id' => $course->id])); ?>" class="btn btn-outline-primary round mr-1 mb-1 waves-effect waves-light">ویرایش</a>
                                        <a class="btn btn-outline-danger round mr-1 mb-1 waves-effect waves-light" href="<?php echo e(route('admin.deleteCourse',['id' => $course->id])); ?>" onclick="event.preventDefault();
                                                     document.getElementById('del').submit();">حذف</a>
                                        <form id="del" action="<?php echo e(route('admin.deleteCourse',['id' => $course->id])); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/courses/create.blade.php ENDPATH**/ ?>
