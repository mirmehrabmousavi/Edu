<div class="col-lg-3 col-md-3">
    <div class="dashboard-navbar">

        <div class="d-user-avater">
            <img src="<?php echo e((!empty(auth()->user()->profile)) ? url('upload/admin/settings/'.auth()->user()->profile) : url('upload/no-profile.jpg')); ?>" class="img-fluid avater" alt="">
            <h4><?php echo e((!empty(auth()->user()->fname)) ? auth()->user()->fname . ' ' . auth()->user()->lname : auth()->user()->email); ?></h4>
            <span><?php echo e(auth()->user()->number); ?></span>
        </div>

        <div class="d-navigation">
            <ul id="side-menu">
                <?php if(auth()->user()->is_seller == 1 || auth()->user()->is_admin === 1): ?>
                    <li class="active"><a href="<?php echo e(route('home')); ?>"><i class="ti-user"></i>داشبورد</a></li>
                    <li><a href="<?php echo e(route('myCourse')); ?>"><i class="ti-book"></i>دوره های من</a></li>
                    <li><a href="<?php echo e(route('myLesson')); ?>"><i class="ti-book"></i>درس های من</a></li>
                    <li><a href="<?php echo e(route('myClass')); ?>"><i class="ti-book"></i>کلاس های من</a></li>
                    <li><a href="<?php echo e(route('savedCourse')); ?>"><i class="ti-heart"></i>دوره های مورد علاقه</a></li>
                    <li><a href="<?php echo e(route('purchasedCourse')); ?>"><i class="ti-heart"></i>دوره های خریده شده</a></li>
                    <li><a href="<?php echo e(route('ticket.create')); ?>"><i class="ti-pencil"></i>ارسال تیکت</a></li>
                    <li><a href="<?php echo e(route('myTickets')); ?>"><i class="ti-menu"></i>تیکت ها</a></li>
                    <li><a href="<?php echo e(route('myPays')); ?>"><i class="ti-bag"></i>پرداخت ها</a></li>
                    <li><a href="<?php echo e(route('myAccount')); ?>"><i class="ti-settings"></i>تنظیمات</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();"><i class="ti-power-off"></i>خروج</a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <li class="active"><a href="<?php echo e(route('home')); ?>"><i class="ti-user"></i>داشبورد</a></li>
                    <li><a href="<?php echo e(route('savedCourse')); ?>"><i class="ti-heart"></i>دوره های مورد علاقه</a></li>
                    <li><a href="<?php echo e(route('purchasedCourse')); ?>"><i class="ti-heart"></i>دوره های خریده شده</a></li>
                    <li><a href="<?php echo e(route('myClass')); ?>"><i class="ti-heart"></i>کلاس های من</a></li>
                    <li><a href="<?php echo e(route('ticket.create')); ?>"><i class="ti-pencil"></i>ارسال تیکت</a></li>
                    <li><a href="<?php echo e(route('myTickets')); ?>"><i class="ti-heart"></i>تیکت ها</a></li>
                    <li><a href="<?php echo e(route('myPays')); ?>"><i class="ti-shopping-cart"></i>پرداخت ها</a></li>
                    <li><a href="<?php echo e(route('myAccount')); ?>"><i class="ti-settings"></i>تنظیمات</a></li>

                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="ti-power-off"></i>خروج</a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
            </ul>
        </div>

    </div>


</div>
<?php /**PATH D:\Installed\www\Edu\resources\views/dashboard/layout/aside.blade.php ENDPATH**/ ?>