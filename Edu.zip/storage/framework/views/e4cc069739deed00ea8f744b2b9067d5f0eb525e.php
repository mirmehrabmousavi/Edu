<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">کلاس ها</h4>
                    <a href="<?php echo e(route('onlineClass.create')); ?>" class="btn btn-outline-primary round mr-1 mb-1 waves-effect waves-light"><i class="fa fa-plus"></i>افزودن</a>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">کاربر</th>
                                <th scope="col">عنوان</th>
                                <th scope="col">تاریخ شروع کلاس</th>
                                <th scope="col">مدت زمان دوره</th>
                                <th scope="col">لینک ورود به کلاس</th>
                                <th scope="col">گذرواژه</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $onlineClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($value->user_id); ?></td>
                                    <td><?php echo e($value->topic); ?></td>
                                    <td><?php echo e($value->start_at); ?></td>
                                    <td><?php echo e($value->duration); ?></td>
                                    <td class="text-success"><a href="<?php echo e($value->join_url); ?>" target="_blank">ورود به کلاس</a></td>
                                    <td><?php echo e($value->password); ?></td>
                                    <td>
                                        <a class="btn btn-outline-primary round mr-1 mb-1 waves-effect waves-light" href="<?php echo e(route('onlineClass.edit',['id' => $value->id])); ?>">ویرایش</a>
                                        <a class="btn btn-outline-danger round mr-1 mb-1 waves-effect waves-light" href="<?php echo e(route('onlineClass.destroy',['id' => $value->id])); ?>" onclick="event.preventDefault();
                                                     document.getElementById('del').submit();">حذف</a>
                                        <form id="del" action="<?php echo e(route('onlineClass.destroy',['id' => $value->id])); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/onlineClass/index.blade.php ENDPATH**/ ?>