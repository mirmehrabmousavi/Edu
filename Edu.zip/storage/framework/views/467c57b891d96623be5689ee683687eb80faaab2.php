<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">کاربران</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">نام</th>
                                <th scope="col">نام خانوادگی</th>
                                <th scope="col">شماره تماس</th>
                                <th scope="col">ایمیل</th>
                                <th scope="col">آدرس</th>
                                <th scope="col">کدپستی</th>
                                <th scope="col">پروفایل</th>
                                <th scope="col">Admin</th>
                                <th scope="col">Teacher</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($user->fname); ?></td>
                                    <td><?php echo e($user->lname); ?></td>
                                    <td><?php echo e($user->number); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->address); ?></td>
                                    <td><?php echo e($user->postcode); ?></td>
                                    <td><?php echo e($user->profile); ?></td>
                                    <td><?php echo e(($user->is_admin) ? 'ادمین' : '-'); ?></td>
                                    <td><?php echo e(($user->is_seller) ? 'مدرس' : '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/admin/users/create.blade.php ENDPATH**/ ?>
