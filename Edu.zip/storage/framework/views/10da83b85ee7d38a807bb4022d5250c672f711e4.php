<?php $__env->startSection('content'); ?>

    <!-- ============================ Page Title Start================================== -->
    <section class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">

                    <div class="breadcrumbs-wrap">
                        <h1 class="breadcrumb-title">لزوم یادگیری زبان در دنیای امروزی!</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">خانه</a></li>
                                <li class="breadcrumb-item active" aria-current="page">بلاگ</li>
                            </ol>
                        </nav>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- ============================ Page Title End ================================== -->

    <!-- ============================ Agency List Start ================================== -->
    <section class="gray">

        <div class="container">

            <!-- row Start -->
            <div class="row">

                <!-- Blog Detail -->
                <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                    <div class="article_detail_wrapss single_article_wrap format-standard">
                        <div class="article_body_wrap">

                            <div class="article_featured_image">
                                <img class="img-fluid"
                                     src="<?php echo e(($blog->image != null) ? '/upload/admin/blog/'.$blog->image : url('/upload/no-image.png')); ?>"
                                     alt="">
                            </div>

                            <?php echo $blog->desc; ?>

                        </div>
                    </div>

                    <!-- Author Detail -->
                    <div class="article_detail_wrapss single_article_wrap format-standard">

                        <div class="article_posts_thumb">
                            <?php $user = \App\Models\User::where('email',$blog->user_id)->get(); ?>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="img"><img class="img-fluid" src="<?php echo e(($val->profile != null) ? '/upload/admin-images/'.$val->profile : '/upload/no-profile.jpg'); ?>" alt=""></span>
                            <h3 class="pa-name"><?php echo e($val->email); ?></h3>
                            <h5 class="pa-name"><?php echo e($val->fname.' '.$val->lname); ?></h5>
                            <ul class="social-links">
                                <li><a href="<?php echo e($val->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="<?php echo e($val->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="<?php echo e($val->linkedin); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="<?php echo e($val->instagram); ?>"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                </div>

                <!-- Single blog Grid -->
                <div class="col-lg-4 col-md-12 col-sm-12 col-12">

                    <!-- Trending Posts -->
                    <div class="single_widgets widget_thumb_post">
                        <h4 class="title">پرمخاطب</h4>
                        <ul>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
								<span class="left">
                                    <img src="<?php echo e(($blog->image != null) ? '/upload/admin/blog/'.$blog->image : url('/upload/no-image.png')); ?>" alt="" class="">
                                </span>
                                <span class="right">
                                    <a class="feed-title" href="<?php echo e(route('showBlog',['id' => $val->id])); ?>"><?php echo e($val->title); ?></a>
                                    <span class="post-date"><i class="ti-calendar"></i><?php echo e($val->updated_at->diffForHumans()); ?></span>
                                </span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Tags Cloud -->
                    <div class="single_widgets widget_tags">
                        <h4 class="title">تگ</h4>
                        <ul>
                            <?php $__currentLoopData = explode(",",$blog->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href=""><?php echo e($tag); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                </div>

            </div>
            <!-- /row -->

        </div>

    </section>
    <!-- ============================ Agency List End ================================== -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\Edu\resources\views/blog/show.blade.php ENDPATH**/ ?>