<div class="col-lg-3 col-md-3">
    <div class="dashboard-navbar">

        <div class="d-user-avater">
            <img src="<?php echo e((!empty(auth()->user()->profile)) ? url('upload/admin_images/'.auth()->user()->profile) : url('upload/no-profile.jpg')); ?>" class="img-fluid avater" alt="">
            <h4><?php echo e((!empty(auth()->user()->fname)) ? auth()->user()->fname . ' ' . auth()->user()->lname : auth()->user()->email); ?></h4>
            <span><?php echo e(auth()->user()->number); ?></span>
        </div>

        <div class="d-navigation">
            <ul id="side-menu">
                <?php if(auth()->user()->is_seller == 1 || auth()->user()->is_admin === 1): ?>
                    <li class="active"><a href="<?php echo e(route('home')); ?>"><i class="ti-user"></i>داشبورد</a></li>
                    <li><a href="add-listing.html"><i class="ti-plus"></i>افزودن دوره جدید</a></li>
                    <li><a href="<?php echo e(route('myCourse')); ?>"><i class="ti-book"></i>دوره های من</a></li>
                    <li><a href="add-listing.html"><i class="ti-plus"></i>افزودن کلاس جدید</a></li>
                    <li><a href="saved-courses.html"><i class="ti-book"></i>کلاس های من</a></li>
                    <li><a href="saved-courses.html"><i class="ti-heart"></i>دوره های ذخیره شده</a></li>
                    <li><a href="my-profile.html"><i class="ti-bag"></i>پرداخت ها</a></li>
                    <li><a href="settings.html"><i class="ti-settings"></i>تنظیمات</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();"><i class="ti-power-off"></i>خروج</a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php else: ?>
                    <li class="active"><a href="<?php echo e(route('home')); ?>"><i class="ti-user"></i>داشبورد</a></li>
                    <li><a href="saved-courses.html"><i class="ti-heart"></i>دوره های ذخیره شده</a></li>
                    <li><a href="my-profile.html"><i class="ti-heart"></i>کلاس های من</a></li>
                    <li><a href="my-order.html"><i class="ti-shopping-cart"></i>پرداخت ها</a></li>
                    <li><a href="settings.html"><i class="ti-settings"></i>تنظیمات</a></li>
                    <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="ti-power-off"></i>خروج</a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
            </ul>
        </div>

    </div>


</div>
<?php /**PATH D:\Installed\www\Edu\resources\views/layout/aside.blade.php ENDPATH**/ ?>
